# ShopEasy Online Shopping Demo

A responsive single-page shopping website built with HTML, CSS, and JavaScript.

## Features
- Product search
- Add products to cart
- Increase/decrease quantities and remove products
- Automatic subtotal, cart count, and total calculation
- Clear cart and demo checkout
- Responsive product grid

## Run locally
Open `index.html` in a modern browser. Internet access is required for the remote Unsplash product images.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Select the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site.

Note: Checkout is a demonstration only; it does not process payments.
